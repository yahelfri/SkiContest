package StatePattern;

public interface RacerState {
	/**
	 * func that return the sate in string
	 * @return String
	 */
	public String alert();
}
