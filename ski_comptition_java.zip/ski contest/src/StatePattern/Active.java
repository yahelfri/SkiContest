package StatePattern;

public class Active implements RacerState {

	@Override
	public String alert() {
		return "Active";
		
	}

}
