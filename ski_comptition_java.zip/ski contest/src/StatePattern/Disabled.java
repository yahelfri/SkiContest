package StatePattern;

public class Disabled implements RacerState {

	@Override
	public String alert() {
		return "Disabled";
		// TODO Auto-generated method stub
		
	}

}
