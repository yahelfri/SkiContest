package StatePattern;

public class Injured implements RacerState {

	@Override
	public String alert() {
		return "Injured";
		// TODO Auto-generated method stub
		
	}

}
